var mySwiper = new Swiper ('.swiper-container', {
    direction: 'vertical',
    loop: true,			    
    // 如果需要前进后退按钮
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    
    onInit: function(swiper){ //Swiper2.x的初始化是onFirstInit
        swiperAnimateCache(swiper); //隐藏动画元素 
        swiperAnimate(swiper); //初始化完成开始动画
    }, 
    onSlideChangeEnd: function(swiper){ 
        swiperAnimate(swiper); //每个slide切换结束时也运行当前slide动画
    } 			    
})       

var flag=false;
$(".img2").click(function(){				
	if(flag){
		$(".mis").get(0).play();
		$(".img2").css("animation","move 2s infinite linear").attr("src","images/audio1.png");
		flag=false;
	}else{
		$(".mis").get(0).pause();
		$(".img2").css("animation","_move").attr("src","images/stopAudio1.png");
		flag=true;
	}
	
})